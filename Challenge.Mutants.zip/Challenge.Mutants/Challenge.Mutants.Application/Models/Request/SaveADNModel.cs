﻿namespace Challenge.Mutants.Application.Models.Request
{
    public class SaveADNModel
    {
        public string[] Dna { get; set; }
    }
}
