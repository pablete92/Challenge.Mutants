﻿namespace Challenge.Mutants.Domain
{
    public class DummyDomain
    {
    }
}
