﻿namespace Challenge.Mutants.Infrastructure.Data
{
    public enum SqlCommandTypeInvocation
    {
        StoredProcedure = 0,
        Function = 1
    }
}
