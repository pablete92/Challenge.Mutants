﻿namespace Challenge.Mutants.Infrastructure
{
    public class DummyInfrastructure
    {
    }
}
