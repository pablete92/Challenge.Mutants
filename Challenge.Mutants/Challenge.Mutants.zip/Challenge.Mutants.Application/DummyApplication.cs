﻿namespace Challenge.Mutants.Application
{
    public class DummyApplication
    {
    }
}
