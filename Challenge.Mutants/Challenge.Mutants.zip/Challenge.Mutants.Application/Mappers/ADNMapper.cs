﻿using Challenge.Mutants.Application.Models;
using Challenge.Mutants.Application.Models.Request;
using Challenge.Mutants.Infrastructure.Models;

namespace Challenge.Mutants.Application.Mappers
{
    public class ADNMapper : MapperBase<AdnModel, SaveADNModel> { }
}
