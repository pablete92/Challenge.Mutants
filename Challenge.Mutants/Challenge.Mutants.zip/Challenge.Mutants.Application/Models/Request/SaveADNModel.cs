﻿namespace Challenge.Mutants.Application.Models.Request
{
    public class SaveADNModel
    {
        public string Adn { get; set; }

        public bool Mutant { get; set; }
    }
}
